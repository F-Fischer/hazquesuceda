###################
Haz que suceda!
###################

###################
Trabajo Final de Carrera 
###################

Bottino Carolina y Fischer Francisco

Ingeniería de Sistemas 

Universidad Católica de Córdoba


El siguiente proyecto corresponde a nuestro Trabajo Final. En el mismo presentamos una plataforma en la que aquellos 
con grandes ideas y sin posibilidades financieras de concretarlas se encuentran con aquellos que poseen dinero y 
quieren invertirlo.
