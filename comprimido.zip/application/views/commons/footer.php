<footer>
    <div class="row">
        <div class="col-lg-12">
            <p> Copyright © Haz que suceda! 2016</p>
        </div>
    </div>
</footer>

<!-- jQuery -->
<!--<script src="<?php //echo base_url('assets/js/jquery.js'); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo base_url('assets/js/jquery.easing.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.fittext.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/wow.min.js'); ?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('assets/js/creative.js'); ?>"></script>

</body>